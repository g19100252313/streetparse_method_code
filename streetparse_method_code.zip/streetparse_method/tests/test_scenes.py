import pytest
from streetparse.scenes import classify_scene,group_error_summary


def test_reference_thresholds_precedence_and_ties():
    assert classify_scene(.7,.1,.10)=='dynamic'
    assert classify_scene(.3,.2,.09)=='building'
    assert classify_scene(.2,.3,.09)=='vegetation'
    assert classify_scene(.3,.3,.09)=='building'
    assert classify_scene(.29,.29,.09)=='mixed'
    with pytest.raises(ValueError):classify_scene(float('nan'),.2,.1)


def test_conditional_centroid_and_image_weighting():
    rows=[{'image_id':'a','proportion_error_pp':1,'centroid_error':.1,'grid_error':.2},
          {'image_id':'b','proportion_error_pp':3,'centroid_error':'','grid_error':.4}]
    result=group_error_summary(rows)
    assert result['n_images']==2 and result['proportion_mae_pp']==2
    assert result['centroid_pairs']==1 and result['centroid_distance']==.1
    assert result['grid_mae']==pytest.approx(.3)
