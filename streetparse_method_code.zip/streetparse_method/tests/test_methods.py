import numpy as np
import pytest
import torch

from streetparse.labels import RAW_IDS, GROUPS, GROUP_LUT, to_train_ids
from streetparse.losses import boundaries, joint_loss
from streetparse.metrics import boundary_numpy, boundary_f1, SegmentationMetrics
from streetparse.models import PaperModel, predict_labels
from streetparse.quantify import quantify, compare, summarize


def test_encoding_is_partition():
    assert to_train_ids(np.array([RAW_IDS], dtype=np.uint8)).tolist() == [list(range(19))]
    assert to_train_ids(np.array([[0, 255, 34]])).tolist() == [[255, 255, 255]]
    assert sorted(c for _, classes in GROUPS for c in classes) == list(range(19))
    assert GROUP_LUT[255] == 0


def test_hand_calculated_quantification():
    labels = np.array([[8, 8, 2, 2], [8, 8, 3, 3]], dtype=np.uint8)
    q = quantify(labels, grid_size=2)
    g = q['groups']['vegetation']
    assert g['proportion'] == 0.5
    assert g['cx'] == pytest.approx(1/6)
    assert g['cy'] == 0.5
    assert g['grid'] == [[1, 0], [1, 0]]
    assert g['grid_mean'] == 0.5
    assert g['grid_std'] == 0.5
    assert g['left'] == 1
    # x=1/3 belongs to center; x=2/3 belongs to right.
    assert g['center'] == 1
    assert g['right'] == 0
    assert q['interface_proportion'] == 0.5
    assert np.isnan(q['groups']['sky']['cx'])


def test_shared_mask_excludes_prediction_in_void():
    ref = np.full((20, 20), 8, dtype=np.uint8)
    ref[:, 10:] = 255
    pred = np.full_like(ref, 8)
    pred[:, 10:] = 2
    p, r, rows = compare(pred, ref, 'toy')
    assert p['groups']['building']['pixels'] == 0
    assert p['groups']['vegetation']['proportion'] == 1
    assert p['valid_grids'] == r['valid_grids'] == 50
    assert all(row['proportion_error_pp'] == 0 for row in rows)
    assert all(row['grid_error'] == 0 for row in rows)


def test_grid_half_coverage_included():
    labels = np.zeros((20, 20), dtype=np.uint8)
    labels[:, ::2] = 255
    result = quantify(labels)
    assert result['valid_grids'] == 100
    assert result['groups']['road']['grid_mean'] == 1


def test_grid_floor_partition_non_divisible():
    q = quantify(np.full((13, 17), 8, dtype=np.uint8))
    assert q['valid_grids'] == 100
    assert np.asarray(q['groups']['vegetation']['grid']).sum() == 100
    assert q['groups']['vegetation']['cx'] == pytest.approx(0.5)
    assert len(q['groups']['vegetation']['q']) == 103


def test_empty_domain_and_single_pixel():
    q = quantify(np.full((10, 10), 255, dtype=np.uint8))
    assert q['valid_grids'] == q['valid_pixels'] == 0
    assert np.isnan(q['groups']['road']['proportion'])
    single = quantify(np.array([[8]], dtype=np.uint8))
    assert single['groups']['vegetation']['cx'] == 0
    assert single['groups']['vegetation']['cy'] == 0


def test_presence_errors_and_per_image_mean():
    ref = np.full((20, 20), 8, dtype=np.uint8)
    pred = np.full_like(ref, 2)
    _, _, rows = compare(pred, ref, 'miss')
    result = summarize(rows)
    assert result['vegetation']['miss'] == 1
    assert result['building']['false_positive'] == 1
    assert result['vegetation']['proportion_mae_pp'] == 100
    assert result['vegetation']['grid_mae'] == 1
    assert result['vegetation']['paired_present'] == 0
    assert np.isnan(result['vegetation']['centroid_mean_distance'])


def test_centroid_distance_hand_calculation():
    ref = np.zeros((20, 20), dtype=np.uint8)
    pred = ref.copy()
    ref[:, :10] = 8
    pred[:, 10:] = 8
    _, _, rows = compare(pred, ref, 'shift')
    g = next(r for r in rows if r['group'] == 'vegetation')
    assert g['proportion_error_pp'] == 0
    assert g['centroid_error'] == pytest.approx(10/19)
    assert g['grid_error'] == 1


def test_boundary_void_and_in_bounds_neighbours():
    labels = np.array([[0, 0, 1], [0, 255, 1]], dtype=np.uint8)
    edge, valid = boundaries(torch.tensor(labels.astype(np.int64))[None])
    expected_valid = np.array([[True, False, True], [False, False, False]])
    assert np.array_equal(valid[0].numpy(), expected_valid)
    np_edge, np_valid = boundary_numpy(labels)
    assert np.array_equal(np_valid, valid[0].numpy())
    assert np.array_equal(np_edge, edge[0].numpy())
    assert edge[0, 0, 2]
    assert not edge[0, 0, 0]


def test_boundary_f1_conventions_and_euclidean_tolerance():
    ref = np.zeros((10, 10), dtype=np.uint8)
    assert np.isnan(boundary_f1(ref, ref))
    ref[:, 5:] = 1
    assert boundary_f1(ref, ref) == 1
    assert boundary_f1(np.zeros_like(ref), ref) == 0
    pred = np.zeros_like(ref)
    pred[:, 7:] = 1
    assert boundary_f1(pred, ref, tolerance=2) == 1
    pred[:, :] = 0
    pred[:, 9:] = 1
    assert boundary_f1(pred, ref, tolerance=2) == 0


def test_semantic_and_boundary_loss_reference():
    target = torch.tensor([[[0, 1], [0, 1]]])
    output = {'semantic': torch.zeros(1, 19, 2, 2, requires_grad=True),
              'boundary': torch.zeros(1, 1, 2, 2, requires_grad=True)}
    loss, parts = joint_loss(output, target, 0.2)
    assert float(parts['semantic']) == pytest.approx(np.log(19))
    # All pixels are boundaries, so negative term is zero, preserving factor 1/2.
    assert float(parts['boundary']) == pytest.approx(0.5*np.log(2))
    assert float(loss.detach()) == pytest.approx(np.log(19) + 0.1*np.log(2))
    loss.backward()
    assert output['boundary'].grad is not None


def test_void_sample_excluded_from_batch_mean():
    target = torch.tensor([[[0, 0]], [[255, 255]]])
    outputs = {'semantic': torch.zeros(2, 19, 1, 2, requires_grad=True)}
    loss, parts = joint_loss(outputs, target)
    assert float(loss.detach()) == pytest.approx(np.log(19))
    assert parts['valid_samples'] == 1
    assert joint_loss(outputs, torch.full_like(target, 255)) is None


def test_confusion_ignores_void():
    reference = np.array([[0, 1, 255], [0, 1, 1]], dtype=np.uint8)
    prediction = np.array([[0, 0, 18], [0, 1, 1]], dtype=np.uint8)
    metric = SegmentationMetrics()
    metric.update(prediction, reference)
    result = metric.result()
    assert metric.confusion.sum() == 5
    assert result['class_iou']['road'] == pytest.approx(2/3)
    assert result['class_iou']['sidewalk'] == pytest.approx(2/3)


@pytest.mark.parametrize('architecture,gate,boundary', [
    ('proposed', None, None), ('deeplab', None, None), ('deeplab', True, False),
    ('deeplab', False, True), ('unet', None, None), ('pspnet', None, None)])
def test_models_shapes_and_frozen_bn(architecture, gate, boundary):
    torch.set_num_threads(2)
    model = PaperModel(architecture, gate, boundary, pretrained=False).train()
    assert all(not m.training and m.weight.requires_grad for m in model.modules() if isinstance(m, torch.nn.BatchNorm2d))
    with torch.no_grad():
        result = model(torch.randn(1, 3, 32, 64))
        assert result['semantic'].shape == (1, 19, 32, 64)
        assert ('boundary' in result) == model.use_boundary
        if model.use_boundary:
            assert result['boundary'].shape == (1, 1, 32, 64)
        labels = predict_labels(model, torch.randn(1, 3, 32, 64), (40, 80))
        assert labels.shape == (1, 40, 80)


def test_probability_resize_before_argmax():
    class Fake(torch.nn.Module):
        def forward(self, image, auxiliary=False):
            return {'semantic': torch.tensor([[[[30., -1.]], [[0., 1.]]]])}
    from torch.nn import functional as F
    logits = Fake()(None)['semantic']
    expected = F.interpolate(logits.softmax(1), (1, 5), mode='bilinear', align_corners=False).argmax(1)
    labels = predict_labels(Fake(), torch.zeros(1, 3, 1, 2), (1, 5))
    assert torch.equal(labels, expected)
    assert not torch.equal(labels, F.interpolate(logits, (1, 5), mode='bilinear', align_corners=False).argmax(1))
