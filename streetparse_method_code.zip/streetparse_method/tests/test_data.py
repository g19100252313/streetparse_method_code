import io
import json
import zipfile

import numpy as np
import pytest
from PIL import Image

from streetparse.data import Cityscapes


def image_bytes(array):
    stream = io.BytesIO()
    Image.fromarray(array).save(stream, format='PNG')
    return stream.getvalue()


def test_zip_pairing_partitions_and_geometry(tmp_path):
    data = tmp_path / 'data'
    data.mkdir()
    with zipfile.ZipFile(data / 'leftImg8bit_trainvaltest.zip', 'w') as rgb, zipfile.ZipFile(data / 'gtFine_trainvaltest.zip', 'w') as gt:
        for city in ('aachen', 'darmstadt', 'jena', 'weimar'):
            stem = f'{city}_000000_000019'
            rgb.writestr(f'leftImg8bit/train/{city}/{stem}_leftImg8bit.png', image_bytes(np.zeros((20, 40, 3), dtype=np.uint8)))
            gt.writestr(f'gtFine/train/{city}/{stem}_gtFine_labelIds.png', image_bytes(np.full((20, 40), 21, dtype=np.uint8)))
    assert len(Cityscapes(tmp_path, partition='all')) == 4
    assert len(Cityscapes(tmp_path, partition='fit')) == 1
    assert len(Cityscapes(tmp_path, partition='tune')) == 3
    sample = Cityscapes(tmp_path, eval_size=(10, 10))[0]
    assert sample['image'].shape == (3, 5, 10)
    assert sample['target'].shape == (20, 40)
    assert sample['target'].unique().tolist() == [8]
    sample = Cityscapes(tmp_path, augment=True, crop=(30, 60))[0]
    assert sample['image'].shape == (3, 30, 60)
    assert set(sample['target'].unique().tolist()) <= {8, 255}
    manifest = tmp_path / 'subset.json'
    content = {'split': 'train', 'partition': 'all',
               'sample_ids': ['weimar_000000_000019', 'aachen_000000_000019']}
    manifest.write_text(json.dumps(content))
    subset = Cityscapes(tmp_path, manifest=manifest)
    assert [r['id'] for r in subset.records] == content['sample_ids']
    with pytest.raises(ValueError, match='match'):
        Cityscapes(tmp_path, partition='fit', manifest=manifest)
    content['sample_ids'] = ['missing_id']
    manifest.write_text(json.dumps(content))
    with pytest.raises(ValueError, match='unavailable'):
        Cityscapes(tmp_path, manifest=manifest)


def test_subset_reproducible_city_coverage_and_exact_size():
    from streetparse.subsets import stratified_sample
    records = [{'id': f'{city}_{i:03}', 'city': city} for city, n in [('a', 30), ('b', 5), ('c', 2)] for i in range(n)]
    first = stratified_sample(records, 10, 2026)
    assert first == stratified_sample(list(reversed(records)), 10, 2026)
    assert len(first) == len({r['id'] for r in first}) == 10
    assert {r['city'] for r in first} == {'a', 'b', 'c'}
    assert first != stratified_sample(records, 10, 2027)
    assert len(stratified_sample(records, 37, 2026)) == 37
    with pytest.raises(ValueError):
        stratified_sample(records, 38, 2026)
