from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch
from torch import nn
from torch.utils.data import Dataset

from streetparse import engine


class TinyDataset(Dataset):
    def __init__(self, *args, **kwargs):
        self.records = [{'id': str(i)} for i in range(3)]

    def __len__(self):
        return 3

    def __getitem__(self, index):
        # Random preprocessing exercises the restored global RNG too.
        return {'image': torch.rand(3, 4, 8), 'target': torch.full((4, 8), index, dtype=torch.long)}


class TinyModel(nn.Module):
    def __init__(self, *args, **kwargs):
        super().__init__()
        self.head = nn.Conv2d(3, 19, 1)

    def forward(self, image):
        return {'semantic': self.head(image)}

    def config(self):
        return {'architecture': 'tiny', 'gate': False, 'boundary': False}


def arguments(path, **extra):
    settings = dict(device='cpu', seed=2026, output=str(path), resume=None, data='unused',
                    partition='all', crop=[4, 8], limit=None, batch_size=1, workers=0,
                    architecture='deeplab', gate=None, boundary=None, no_pretrained=True,
                    lr=1e-4, no_amp=True, max_batches=None, epochs=2, accumulation=2,
                    boundary_weight=0.2, eval_size=None, tune_limit=None, log_every=100)
    settings.update(extra)
    return SimpleNamespace(**settings)


def test_epoch_resume_matches_continuous_and_flushes_partial_accumulation(tmp_path, monkeypatch):
    monkeypatch.setattr(engine, 'Cityscapes', TinyDataset)
    monkeypatch.setattr(engine, 'PaperModel', TinyModel)
    save = torch.save
    snapshot = tmp_path / 'epoch1.pt'

    def save_with_snapshot(state, path):
        save(state, path)
        if state['epoch'] == 1:
            save(state, snapshot)

    monkeypatch.setattr(engine.torch, 'save', save_with_snapshot)
    continuous = engine.train(arguments(tmp_path / 'continuous'))
    monkeypatch.setattr(engine.torch, 'save', save)
    resumed = engine.train(arguments(tmp_path / 'resumed', resume=str(snapshot)))
    first = torch.load(continuous, weights_only=False)
    second = torch.load(resumed, weights_only=False)
    # 3 micro-batches with accumulation=2: one full update plus one tail per epoch.
    assert first['updates'] == second['updates'] == 4
    assert first['iteration'] == second['iteration'] == 6
    for key in first['model']:
        assert torch.equal(first['model'][key], second['model'][key])
    assert torch.equal(first['rng_loader'], second['rng_loader'])
    assert np.array_equal(first['rng_numpy'][1], second['rng_numpy'][1])
