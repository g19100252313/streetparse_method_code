import torch
from torch.nn import functional as F


def boundaries(target):
    """Eq. (11): four in-bounds neighbours; void contaminates both sides."""
    if target.ndim != 3:
        raise ValueError('Expected N,H,W target.')
    valid = target != 255
    supervised = valid.clone()
    edge = torch.zeros_like(valid)
    a, b = target[:, :-1, :], target[:, 1:, :]
    different = a != b
    edge[:, :-1, :] |= different
    edge[:, 1:, :] |= different
    supervised[:, :-1, :] &= valid[:, 1:, :]
    supervised[:, 1:, :] &= valid[:, :-1, :]
    a, b = target[:, :, :-1], target[:, :, 1:]
    different = a != b
    edge[:, :, :-1] |= different
    edge[:, :, 1:] |= different
    supervised[:, :, :-1] &= valid[:, :, 1:]
    supervised[:, :, 1:] &= valid[:, :, :-1]
    return edge & supervised, supervised


def joint_loss(outputs, target, weight=0.2):
    """Equal mean over valid samples; boundary +/- classes each have weight 1/2."""
    logits = outputs['semantic'].float()
    valid = target != 255
    count = valid.flatten(1).sum(1)
    keep = count > 0
    if not keep.any():
        return None
    pixel_loss = F.cross_entropy(logits, target, ignore_index=255, reduction='none')
    semantic = pixel_loss.flatten(1).sum(1) / count.clamp_min(1)
    boundary = torch.zeros_like(semantic)
    if 'boundary' in outputs:
        edge, supervised = boundaries(target)
        # FP32 avoids AMP rounding 1-1e-7 to 1, matching paper's clipping rule.
        probability = outputs['boundary'][:, 0].float().sigmoid().clamp(1e-7, 1 - 1e-7)
        positive, negative = edge & supervised, (~edge) & supervised
        np_ = positive.flatten(1).sum(1).clamp_min(1)
        nn_ = negative.flatten(1).sum(1).clamp_min(1)
        boundary = -0.5 * ((probability.log() * positive).flatten(1).sum(1) / np_ +
                           ((1 - probability).log() * negative).flatten(1).sum(1) / nn_)
    total = (semantic + weight * boundary)[keep].mean()
    return total, {'semantic': semantic[keep].mean().detach(), 'boundary': boundary[keep].mean().detach(),
                   'valid_samples': int(keep.sum().item())}
