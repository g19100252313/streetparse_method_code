"""Paired Cityscapes reader for both extracted folders and original ZIPs."""
import io
import json
import random
import zipfile
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageOps
from torch.utils.data import Dataset

from .labels import to_train_ids

TUNE_CITIES = {'darmstadt', 'jena', 'weimar'}
MEAN = torch.tensor((0.485, 0.456, 0.406)).view(3, 1, 1)
STD = torch.tensor((0.229, 0.224, 0.225)).view(3, 1, 1)


def normalize(image):
    tensor = torch.from_numpy(np.asarray(image, dtype=np.float32).copy()).permute(2, 0, 1) / 255.
    return (tensor - MEAN) / STD


class Cityscapes(Dataset):
    def __init__(self, root, split='train', partition='all', augment=False,
                 crop=(512, 1024), eval_size=None, limit=None, manifest=None):
        self.root = Path(root).resolve()
        self.split = split
        self.partition = partition
        self.augment = augment
        self.crop = tuple(crop)
        self.eval_size = tuple(eval_size) if eval_size else None
        self._archives = {}
        self.sources = {}
        if split not in ('train', 'val'):
            raise ValueError('Public fine semantic evaluation supports train/val only.')
        if partition not in ('all', 'fit', 'tune') or (partition != 'all' and split != 'train'):
            raise ValueError('fit/tune partitions are restricted to official train.')
        for folder, archive in [('leftImg8bit', 'leftImg8bit_trainvaltest.zip'),
                                ('gtFine', 'gtFine_trainvaltest.zip')]:
            if (self.root / folder / split).is_dir():
                self.sources[folder] = None
            else:
                candidates = [self.root / 'data' / archive, self.root / archive]
                self.sources[folder] = next((p for p in candidates if p.is_file()), None)
                if self.sources[folder] is None:
                    raise FileNotFoundError(f'Missing {folder}/{split} or {archive} under {self.root}')
        names = self._names('leftImg8bit', '_leftImg8bit.png')
        labels = set(self._names('gtFine', '_gtFine_labelIds.png'))
        self.records = []
        for name in sorted(names):
            city = name.split('/')[-2]
            if partition == 'fit' and city in TUNE_CITIES:
                continue
            if partition == 'tune' and city not in TUNE_CITIES:
                continue
            label = name.replace('leftImg8bit/', 'gtFine/', 1).replace('_leftImg8bit.png', '_gtFine_labelIds.png')
            if label not in labels:
                raise FileNotFoundError(f'Missing paired label: {label}')
            self.records.append({'id': Path(name).name.removesuffix('_leftImg8bit.png'),
                                 'city': city, 'image': name, 'label': label})
        if manifest is not None:
            content = json.loads(Path(manifest).read_text(encoding='utf-8-sig'))
            if not isinstance(content, dict) or content.get('split') != split or content.get('partition') != partition:
                raise ValueError('Subset manifest must match the requested split and partition.')
            ids = content.get('sample_ids', [])
            if not ids or len(ids) != len(set(ids)):
                raise ValueError('Subset sample_ids must be nonempty and unique.')
            available = {r['id']: r for r in self.records}
            unknown = set(ids) - set(available)
            if unknown:
                raise ValueError(f'Subset contains unavailable samples: {sorted(unknown)[:3]}')
            # Use authoritative dataset paths rather than paths from a manifest.
            self.records = [available[sample_id] for sample_id in ids]
        if limit is not None:
            if limit < 1:
                raise ValueError('limit must be positive')
            self.records = self.records[:limit]
        if not self.records:
            raise ValueError('No image/label pairs found.')

    def _names(self, folder, suffix):
        source = self.sources[folder]
        if source is None:
            return [p.relative_to(self.root).as_posix() for p in (self.root / folder / self.split).rglob('*' + suffix)]
        with zipfile.ZipFile(source) as archive:
            return [n for n in archive.namelist() if n.startswith(f'{folder}/{self.split}/') and n.endswith(suffix)]

    def _read(self, folder, name):
        source = self.sources[folder]
        if source is None:
            with Image.open(self.root / name) as im:
                return im.copy()
        if folder not in self._archives:
            self._archives[folder] = zipfile.ZipFile(source)
        with Image.open(io.BytesIO(self._archives[folder].read(name))) as im:
            return im.copy()

    def __getstate__(self):
        state = self.__dict__.copy()
        state['_archives'] = {}  # Windows spawned workers open their own handles.
        return state

    def __len__(self):
        return len(self.records)

    def load_pair(self, index):
        record = self.records[index]
        rgb = self._read('leftImg8bit', record['image']).convert('RGB')
        raw = self._read('gtFine', record['label'])
        if rgb.size != raw.size:
            raise ValueError(f'Size mismatch: {record["id"]}: {rgb.size}, {raw.size}')
        return rgb, Image.fromarray(to_train_ids(raw))

    def __getitem__(self, index):
        image, target = self.load_pair(index)
        original_hw = (image.height, image.width)
        if self.augment:
            scale = random.uniform(0.5, 2.0)
            size = (max(1, round(image.width * scale)), max(1, round(image.height * scale)))
            image = image.resize(size, Image.Resampling.BILINEAR)
            target = target.resize(size, Image.Resampling.NEAREST)
            ch, cw = self.crop
            pad = (0, 0, max(0, cw - image.width), max(0, ch - image.height))
            image = ImageOps.expand(image, pad, fill=(124, 116, 104))
            target = ImageOps.expand(target, pad, fill=255)
            x = random.randint(0, image.width - cw)
            y = random.randint(0, image.height - ch)
            box = (x, y, x + cw, y + ch)
            image, target = image.crop(box), target.crop(box)
            if random.random() < 0.5:
                image, target = ImageOps.mirror(image), ImageOps.mirror(target)
        elif self.eval_size:
            # Keep the complete field of view and aspect ratio; labels stay original.
            eh, ew = self.eval_size
            scale = min(eh / image.height, ew / image.width)
            image = image.resize((max(1, round(image.width * scale)), max(1, round(image.height * scale))),
                                 Image.Resampling.BILINEAR)
        return {'image': normalize(image),
                'target': torch.from_numpy(np.asarray(target, dtype=np.int64).copy()),
                'id': self.records[index]['id'], 'original_hw': original_hw}
