import torch
from torch import nn
from torch.nn import functional as F
from torchvision.models import resnet50, ResNet50_Weights


def up(x, size):
    return F.interpolate(x, size=size, mode='bilinear', align_corners=False)


class ConvBNReLU(nn.Sequential):
    def __init__(self, cin, cout, kernel=3, dilation=1):
        super().__init__(nn.Conv2d(cin, cout, kernel, padding=dilation * (kernel // 2),
                                  dilation=dilation, bias=False),
                         nn.BatchNorm2d(cout), nn.ReLU(inplace=True))


class ASPP(nn.Module):
    def __init__(self):
        super().__init__()
        self.branches = nn.ModuleList([ConvBNReLU(2048, 256, 1)] +
                                     [ConvBNReLU(2048, 256, 3, r) for r in (6, 12, 18)])
        self.pool = nn.Sequential(nn.AdaptiveAvgPool2d(1), ConvBNReLU(2048, 256, 1))
        self.project = ConvBNReLU(1280, 256, 1)

    def forward(self, x):
        return self.project(torch.cat([b(x) for b in self.branches] +
                                      [up(self.pool(x), x.shape[-2:])], dim=1))


class PaperModel(nn.Module):
    """Proposed, DeepLabv3+, U-Net and PSPNet with ResNet-50 encoders."""
    def __init__(self, architecture='proposed', gate=None, boundary=None, pretrained=True):
        super().__init__()
        if architecture not in ('proposed', 'deeplab', 'unet', 'pspnet'):
            raise ValueError(architecture)
        self.architecture = architecture
        self.use_gate = (architecture == 'proposed') if gate is None else gate
        self.use_boundary = (architecture == 'proposed') if boundary is None else boundary
        if architecture in ('unet', 'pspnet') and (self.use_gate or self.use_boundary):
            raise ValueError('Gate/boundary ablations apply to DeepLabv3+ only.')
        # OS16 for DeepLab/PSP; classic multilevel OS32 encoder for U-Net.
        self.encoder = resnet50(weights=ResNet50_Weights.IMAGENET1K_V1 if pretrained else None,
                                replace_stride_with_dilation=[False, False, architecture != 'unet'])
        self.encoder.fc = nn.Identity()
        self.encoder.avgpool = nn.Identity()
        if architecture in ('proposed', 'deeplab'):
            self.aspp = ASPP()
            self.low = ConvBNReLU(256, 48, 1)
            if self.use_gate:
                self.gate = nn.Conv2d(304, 48, 1)
            self.decoder = nn.Sequential(ConvBNReLU(304, 256), ConvBNReLU(256, 256))
        elif architecture == 'pspnet':
            self.pools = nn.ModuleList([nn.Sequential(nn.AdaptiveAvgPool2d(s), ConvBNReLU(2048, 256, 1))
                                        for s in (1, 2, 3, 6)])
            self.decoder = nn.Sequential(ConvBNReLU(3072, 256), ConvBNReLU(256, 256))
        else:
            self.bridge = ConvBNReLU(2048, 256, 1)
            self.skip_channels = (1024, 512, 256, 64)
            self.blocks = nn.ModuleList([nn.Sequential(ConvBNReLU(256 + c, 256), ConvBNReLU(256, 256))
                                         for c in self.skip_channels])
        self.semantic_head = nn.Conv2d(256, 19, 1)
        if self.use_boundary:
            self.boundary_head = nn.Conv2d(256, 1, 1)
        for name, module in self.named_modules():
            if name.startswith('encoder'):
                continue
            if isinstance(module, nn.Conv2d):
                nn.init.kaiming_normal_(module.weight, mode='fan_out', nonlinearity='relu')
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
        self.freeze_bn()

    def freeze_bn(self):
        # Paper explicitly freezes running stats, including newly added BN layers.
        # Affine weights retain requires_grad=True.
        for module in self.modules():
            if isinstance(module, nn.BatchNorm2d):
                module.eval()

    def train(self, mode=True):
        super().train(mode)
        self.freeze_bn()
        return self

    def forward(self, image, auxiliary=True):
        enc = self.encoder
        stem = enc.relu(enc.bn1(enc.conv1(image)))
        low = enc.layer1(enc.maxpool(stem))
        mid = enc.layer2(low)
        upper = enc.layer3(mid)
        high = enc.layer4(upper)
        if self.architecture in ('proposed', 'deeplab'):
            context = up(self.aspp(high), low.shape[-2:])
            detail = self.low(low)
            if self.use_gate:
                detail = detail * torch.sigmoid(self.gate(torch.cat((detail, context), 1)))
            decoded = self.decoder(torch.cat((detail, context), 1))
        elif self.architecture == 'pspnet':
            decoded = self.decoder(torch.cat([high] + [up(b(high), high.shape[-2:]) for b in self.pools], 1))
        else:
            decoded = self.bridge(high)
            for block, skip in zip(self.blocks, (upper, mid, low, stem)):
                decoded = block(torch.cat((up(decoded, skip.shape[-2:]), skip), 1))
        result = {'semantic': up(self.semantic_head(decoded), image.shape[-2:])}
        if self.use_boundary and auxiliary:
            result['boundary'] = up(self.boundary_head(decoded), image.shape[-2:])
        return result

    def config(self):
        return {'architecture': self.architecture, 'gate': self.use_gate, 'boundary': self.use_boundary}


@torch.no_grad()
def predict_labels(model, image, original_hw):
    logits = model(image, auxiliary=False)['semantic'].float()
    # Eq. (1): resize probabilities, rather than labels or logits.
    probability = up(logits.softmax(dim=1), original_hw)
    return probability.argmax(dim=1)
