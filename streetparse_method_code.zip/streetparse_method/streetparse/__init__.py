"""Paper implementation: street-scene parsing and spatial quantification."""
