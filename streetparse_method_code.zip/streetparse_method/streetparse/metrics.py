import numpy as np
from scipy.ndimage import distance_transform_edt

from .labels import CLASS_NAMES


def boundary_numpy(labels):
    labels = np.asarray(labels)
    valid = labels != 255
    supervised = valid.copy()
    edge = np.zeros_like(valid)
    different = labels[:-1, :] != labels[1:, :]
    edge[:-1, :] |= different
    edge[1:, :] |= different
    supervised[:-1, :] &= valid[1:, :]
    supervised[1:, :] &= valid[:-1, :]
    different = labels[:, :-1] != labels[:, 1:]
    edge[:, :-1] |= different
    edge[:, 1:] |= different
    supervised[:, :-1] &= valid[:, 1:]
    supervised[:, 1:] &= valid[:, :-1]
    return edge & supervised, supervised


def boundary_f1(prediction, reference, tolerance=2):
    ref_edge, supervised = boundary_numpy(reference)
    # Set reference-void locations before boundary extraction to use the same domain.
    masked = np.where(reference != 255, prediction, 255)
    pred_edge, _ = boundary_numpy(masked)
    pred_edge &= supervised
    pn, rn = int(pred_edge.sum()), int(ref_edge.sum())
    if not pn and not rn:
        return np.nan
    if not pn or not rn:
        return 0.
    precision = float((distance_transform_edt(~ref_edge)[pred_edge] <= tolerance).mean())
    recall = float((distance_transform_edt(~pred_edge)[ref_edge] <= tolerance).mean())
    return 2 * precision * recall / (precision + recall) if precision + recall else 0.


class SegmentationMetrics:
    def __init__(self):
        self.confusion = np.zeros((19, 19), dtype=np.int64)
        self.f1 = []

    def update(self, prediction, reference):
        valid = reference != 255
        if np.any((prediction[valid] < 0) | (prediction[valid] >= 19)):
            raise ValueError('Invalid predicted class.')
        self.confusion += np.bincount(19 * reference[valid].astype(np.int64) + prediction[valid],
                                     minlength=19*19).reshape(19, 19)
        f1 = boundary_f1(prediction, reference)
        if np.isfinite(f1):
            self.f1.append(f1)

    def result(self):
        tp = np.diag(self.confusion)
        union = self.confusion.sum(0) + self.confusion.sum(1) - tp
        iou = np.divide(tp, union, out=np.full(19, np.nan), where=union > 0)
        return {'miou': float(np.nanmean(iou)) if np.isfinite(iou).any() else np.nan,
                'class_iou': dict(zip(CLASS_NAMES, iou.tolist())),
                'absent_union_classes': [n for n, u in zip(CLASS_NAMES, union) if not u],
                'boundary_f1': float(np.mean(self.f1)) if self.f1 else np.nan,
                'boundary_n_images': len(self.f1), 'confusion_matrix': self.confusion.tolist()}
