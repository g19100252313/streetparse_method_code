import numpy as np

IGNORE = 255
RAW_IDS = (7, 8, 11, 12, 13, 17, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 31, 32, 33)
CLASS_NAMES = ('road', 'sidewalk', 'building', 'wall', 'fence', 'pole',
               'traffic_light', 'traffic_sign', 'vegetation', 'terrain', 'sky',
               'person', 'rider', 'car', 'truck', 'bus', 'train', 'motorcycle', 'bicycle')
GROUPS = (
    ('vegetation', (8,)), ('sky', (10,)), ('building', (2,)),
    ('wall_fence', (3, 4)), ('sidewalk', (1,)), ('road', (0,)),
    ('terrain', (9,)), ('facilities', (5, 6, 7)), ('people', (11, 12)),
    ('vehicles', (13, 14, 15, 16, 17, 18)),
)
COLORS = np.array([(128,64,128),(244,35,232),(70,70,70),(102,102,156),
                   (190,153,153),(153,153,153),(250,170,30),(220,220,0),
                   (107,142,35),(152,251,152),(70,130,180),(220,20,60),
                   (255,0,0),(0,0,142),(0,0,70),(0,60,100),(0,80,100),
                   (0,0,230),(119,11,32)], dtype=np.uint8)
LUT = np.full(256, IGNORE, dtype=np.uint8)
LUT[list(RAW_IDS)] = np.arange(19, dtype=np.uint8)
GROUP_LUT = np.zeros(256, dtype=np.uint8)
for group_id, (_, classes) in enumerate(GROUPS, 1):
    GROUP_LUT[list(classes)] = group_id


def to_train_ids(raw):
    raw = np.asarray(raw)
    if raw.min() < 0 or raw.max() > 255:
        raise ValueError('Expected Cityscapes 8-bit labelIds, not instanceIds.')
    return LUT[raw.astype(np.uint8)]


def colorize(labels):
    labels = np.asarray(labels)
    result = np.zeros((*labels.shape, 3), dtype=np.uint8)
    valid = (labels >= 0) & (labels < 19)
    result[valid] = COLORS[labels[valid]]
    return result
