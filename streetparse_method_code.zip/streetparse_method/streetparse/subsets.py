"""Fixed city-stratified exploratory subsets; separate official train/val pools."""
import random
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from .data import Cityscapes, TUNE_CITIES
from .io import write_json
from .labels import CLASS_NAMES


def stratified_sample(records, count, seed):
    if count < 1 or count > len(records):
        raise ValueError(f'Subset size must be between 1 and {len(records)}.')
    cities = defaultdict(list)
    for record in sorted(records, key=lambda r: r['id']):
        cities[record['city']].append(record)
    # One per city when possible, then allocate remaining slots proportionally.
    allocation = {city: int(count >= len(cities)) for city in cities}
    remaining = count - sum(allocation.values())
    capacity = {city: len(items) - allocation[city] for city, items in cities.items()}
    total_capacity = sum(capacity.values())
    ideals = {city: remaining * cap / total_capacity if total_capacity else 0 for city, cap in capacity.items()}
    for city in cities:
        allocation[city] += int(ideals[city])
    extra = count - sum(allocation.values())
    ranked = sorted(cities, key=lambda city: (-(ideals[city] % 1), city))
    for city in ranked[:extra]:
        allocation[city] += 1
    rng = random.Random(seed)
    selected = []
    for city in sorted(cities):
        selected.extend(rng.sample(cities[city], allocation[city]))
    return sorted(selected, key=lambda r: r['id'])


def prepare_subset(data, output, train_size=100, val_size=20, seed=2026):
    output = Path(output)
    if (output / 'summary.json').exists():
        raise FileExistsError(f'{output} already has a subset. Use a new directory to avoid changing a running experiment.')
    train = Cityscapes(data, 'train')
    val = Cityscapes(data, 'val')
    selected_train = stratified_sample(train.records, train_size, seed)
    selected_val = stratified_sample(val.records, val_size, seed)
    assert not set(r['id'] for r in selected_train) & set(r['id'] for r in selected_val)
    sets = {'train': ('train', 'all', selected_train),
            'fit': ('train', 'fit', [r for r in selected_train if r['city'] not in TUNE_CITIES]),
            'tune': ('train', 'tune', [r for r in selected_train if r['city'] in TUNE_CITIES]),
            'val': ('val', 'all', selected_val)}
    summary = {'seed': seed, 'sampling': 'city-stratified, fixed train/val pools',
               'scope': 'exploratory subset; not full Cityscapes paper evaluation', 'sets': {}}
    for name, (split, partition, records) in sets.items():
        if not records:
            continue
        path = output / f'{name}.json'
        write_json(path, {'split': split, 'partition': partition, 'seed': seed,
                          'sample_ids': [r['id'] for r in records], 'records': records})
        summary['sets'][name] = {'count': len(records), 'cities': dict(sorted(Counter(r['city'] for r in records).items())),
                                 'manifest': str(path.resolve())}
    # Inspect all selected labels, reporting rare-class presence without optimizing on val.
    for name, split in [('train', 'train'), ('val', 'val')]:
        ds = Cityscapes(data, split, manifest=output / f'{name}.json')
        histogram = np.zeros(19, dtype=np.int64)
        presence = np.zeros(19, dtype=np.int64)
        for index in range(len(ds)):
            _, target = ds.load_pair(index)
            labels = np.asarray(target)
            counts = np.bincount(labels[labels != 255], minlength=19)
            histogram += counts
            presence += counts > 0
        summary['sets'][name]['class_pixels'] = dict(zip(CLASS_NAMES, histogram.tolist()))
        summary['sets'][name]['class_present_images'] = dict(zip(CLASS_NAMES, presence.tolist()))
    write_json(output / 'summary.json', summary)
    return summary
