import csv
import json
import math
import random
import time
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from torch.utils.data import DataLoader

from .data import Cityscapes
from .io import write_csv, write_json
from .labels import colorize
from .losses import joint_loss
from .metrics import SegmentationMetrics
from .models import PaperModel, predict_labels
from .quantify import compare, summarize


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def seed_worker(worker_id):
    seed = torch.initial_seed() % 2**32
    np.random.seed(seed)
    random.seed(seed)


def device_for(name):
    if name == 'auto':
        name = 'cuda' if torch.cuda.is_available() else 'cpu'
    if name == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable. Check CUDA PyTorch installation or use --device cpu.')
    return torch.device(name)


def load_model(checkpoint, device):
    state = torch.load(checkpoint, map_location='cpu', weights_only=False)
    model = PaperModel(**state['model_config'], pretrained=False).to(device)
    model.load_state_dict(state['model'])
    model.eval()
    return model, state


@torch.no_grad()
def evaluate(model, dataset, device, output=None, save_examples=0):
    model.eval()
    metrics = SegmentationMetrics()
    rows = []
    start = time.perf_counter()
    for index in range(len(dataset)):
        sample = dataset[index]
        prediction = predict_labels(model, sample['image'][None].to(device), sample['original_hw'])[0].cpu().numpy()
        reference = sample['target'].numpy()
        metrics.update(prediction, reference)
        pred, ref, paired = compare(prediction, reference, sample['id'])
        rows.extend(paired)
        if output is not None:
            out = Path(output)
            write_json(out / 'quantification' / f'{sample["id"]}.json', {'prediction': pred, 'reference': ref})
            if index < save_examples:
                ex = out / 'examples'
                ex.mkdir(parents=True, exist_ok=True)
                rgb, _ = dataset.load_pair(index)
                rgb.save(ex / f'{sample["id"]}_rgb.png')
                Image.fromarray(colorize(prediction)).save(ex / f'{sample["id"]}_prediction.png')
                Image.fromarray(colorize(reference)).save(ex / f'{sample["id"]}_reference.png')
                Image.fromarray(prediction.astype(np.uint8)).save(ex / f'{sample["id"]}_trainIds.png')
                Image.fromarray((0.55 * np.asarray(rgb) + 0.45 * colorize(prediction)).astype(np.uint8)).save(
                    ex / f'{sample["id"]}_overlay.png')
        if (index + 1) % 25 == 0 or index == len(dataset) - 1:
            print(f'Evaluate {index+1}/{len(dataset)}', flush=True)
    report = {'segmentation': metrics.result(), 'quantification': summarize(rows),
              'n_images': len(dataset), 'split': dataset.split, 'partition': dataset.partition,
              'eval_size': dataset.eval_size, 'total_seconds': time.perf_counter() - start}
    if output is not None:
        write_csv(Path(output) / 'per_image_group.csv', rows)
        write_json(Path(output) / 'summary.json', report)
    return report


def train(args):
    device = device_for(args.device)
    seed_everything(args.seed)
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'last.pt').exists() and not args.resume:
        raise FileExistsError(f'{out}/last.pt already exists; use --resume or another --output.')
    dataset = Cityscapes(args.data, 'train', args.partition, augment=True,
                         crop=args.crop, limit=args.limit, manifest=getattr(args, 'manifest', None))
    generator = torch.Generator().manual_seed(args.seed)
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True, num_workers=args.workers,
                        pin_memory=device.type == 'cuda', worker_init_fn=seed_worker, generator=generator)
    model = PaperModel(args.architecture, args.gate, args.boundary,
                       pretrained=not args.no_pretrained and not args.resume).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, betas=(0.9, 0.999), weight_decay=1e-4)
    amp = device.type == 'cuda' and not args.no_amp
    scaler = torch.amp.GradScaler('cuda', enabled=amp)
    batches = min(len(loader), args.max_batches) if args.max_batches else len(loader)
    total_iterations = args.epochs * batches
    start_epoch, iteration, updates, best = 0, 0, 0, -math.inf
    if args.resume:
        state = torch.load(args.resume, map_location='cpu', weights_only=False)
        if state['model_config'] != model.config():
            raise ValueError('Resume architecture/gate/boundary configuration mismatch.')
        previous = state['train_config']
        for key in ('epochs', 'seed', 'partition', 'crop', 'batch_size', 'accumulation', 'lr', 'boundary_weight',
                    'limit', 'max_batches', 'no_amp', 'workers'):
            if previous.get(key) != vars(args).get(key):
                raise ValueError(f'Resume configuration differs in {key}; use original training settings.')
        for key in ('manifest', 'tune_manifest'):
            if previous.get(key) != vars(args).get(key):
                raise ValueError(f'Resume configuration differs in {key}.')
        if state.get('sample_ids') is not None and state['sample_ids'] != [r['id'] for r in dataset.records]:
            raise ValueError('Resume dataset sample IDs changed.')
        model.load_state_dict(state['model'])
        optimizer.load_state_dict(state['optimizer'])
        scaler.load_state_dict(state['scaler'])
        start_epoch, iteration = state['epoch'], state['iteration']
        updates, best = state['updates'], state['best_tune_miou']
        random.setstate(state['rng_python'])
        np.random.set_state(state['rng_numpy'])
        torch.set_rng_state(state['rng_torch'])
        generator.set_state(state['rng_loader'])
        if device.type == 'cuda' and state.get('rng_cuda') is not None:
            torch.cuda.set_rng_state_all(state['rng_cuda'])
    write_json(out / 'config.json', {**vars(args), 'device_resolved': str(device),
                                    'model_config': model.config(), 'torch': torch.__version__,
                                    'gpu': torch.cuda.get_device_name() if device.type == 'cuda' else None})
    write_json(out / 'manifest.json', {'split': 'train', 'partition': args.partition, 'records': dataset.records})
    tune = Cityscapes(args.data, 'train', 'tune', eval_size=args.eval_size, limit=args.tune_limit,
                      manifest=getattr(args, 'tune_manifest', None)) if args.partition == 'fit' else None
    print(f'Train {len(dataset)} images, device={device}, AMP={amp}, model={model.config()}', flush=True)
    for epoch in range(start_epoch, args.epochs):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        losses, semantic_losses, boundary_losses = [], [], []
        accumulated = 0
        begin = time.perf_counter()
        for batch_index, batch in enumerate(loader):
            if batch_index >= batches:
                break
            lr = args.lr * (1 - iteration / total_iterations)**0.9
            for group in optimizer.param_groups:
                group['lr'] = lr
            image, target = batch['image'].to(device), batch['target'].to(device)
            with torch.autocast(device_type=device.type, enabled=amp):
                loss_result = joint_loss(model(image), target, args.boundary_weight)
            iteration += 1
            if loss_result is not None:
                loss, parts = loss_result
                if not torch.isfinite(loss):
                    raise FloatingPointError(f'Non-finite loss at epoch {epoch+1}, batch {batch_index+1}')
                scaler.scale(loss).backward()
                accumulated += 1
                losses.append(float(loss.detach()))
                semantic_losses.append(float(parts['semantic']))
                boundary_losses.append(float(parts['boundary']))
            if accumulated and (accumulated == args.accumulation or batch_index == batches - 1):
                scaler.unscale_(optimizer)
                # Actual contributing micro-batch count handles incomplete/void groups.
                for parameter in model.parameters():
                    if parameter.grad is not None:
                        parameter.grad.div_(accumulated)
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad(set_to_none=True)
                updates += 1
                accumulated = 0
            if (batch_index+1) % args.log_every == 0 or batch_index == batches - 1:
                print(f'Epoch {epoch+1}/{args.epochs} batch {batch_index+1}/{batches} '
                      f'loss={np.mean(losses) if losses else float("nan"):.5f} lr={lr:.3g}', flush=True)
        if not losses:
            raise ValueError('Epoch contains no supervised pixels.')
        tune_miou = None
        improved = False
        if tune is not None:
            report = evaluate(model, tune, device)
            tune_miou = report['segmentation']['miou']
            improved = tune_miou > best
            best = max(best, tune_miou)
            write_json(out / 'tune_latest.json', report)
        row = {'epoch': epoch+1, 'loss': float(np.mean(losses)),
               'semantic_loss': float(np.mean(semantic_losses)), 'boundary_loss': float(np.mean(boundary_losses)),
               'lr': optimizer.param_groups[0]['lr'], 'tune_miou': tune_miou,
               'updates': updates, 'seconds': time.perf_counter() - begin}
        with (out / 'history.csv').open('a', newline='', encoding='utf-8') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(row))
            if stream.tell() == 0:
                writer.writeheader()
            writer.writerow(row)
        state = {'model': model.state_dict(), 'model_config': model.config(), 'optimizer': optimizer.state_dict(),
                 'scaler': scaler.state_dict(), 'epoch': epoch+1, 'iteration': iteration, 'updates': updates,
                 'best_tune_miou': best, 'train_config': vars(args), 'rng_python': random.getstate(),
                 'rng_numpy': np.random.get_state(), 'rng_torch': torch.get_rng_state(),
                 'rng_loader': generator.get_state(),
                 'rng_cuda': torch.cuda.get_rng_state_all() if device.type == 'cuda' else None,
                 'sample_ids': [r['id'] for r in dataset.records]}
        temporary = out / 'last.tmp.pt'
        torch.save(state, temporary)
        temporary.replace(out / 'last.pt')
        if improved:
            torch.save(state, out / 'best.pt')
        print(f'Epoch {epoch+1} saved to {out / "last.pt"}', flush=True)
    return out / 'last.pt'
