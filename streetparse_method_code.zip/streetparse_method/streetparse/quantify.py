"""Equations (15)-(23); one shared reference-valid mask for paired measures."""
import numpy as np
from scipy.stats import spearmanr

from .labels import GROUPS, GROUP_LUT


def quantify(labels, valid=None, grid_size=10):
    labels = np.asarray(labels)
    if labels.ndim != 2 or not np.isin(labels, list(range(19)) + [255]).all():
        raise ValueError('Expected H,W train IDs 0..18 or 255.')
    h, w = labels.shape
    if h < 1 or w < 1 or grid_size < 1:
        raise ValueError('Image and grid dimensions must be positive.')
    valid = labels != 255 if valid is None else np.asarray(valid, dtype=bool)
    if valid.shape != labels.shape or np.any(valid & (labels == 255)):
        raise ValueError('Shared valid mask must select classified pixels.')
    total = int(valid.sum())
    x = np.arange(w) / max(w - 1, 1)
    y = np.arange(h) / max(h - 1, 1)
    group_map = GROUP_LUT[labels.astype(np.uint8)]
    # Paper Eq.19 explicitly uses floor boundaries, covering all pixels once.
    xs = np.arange(grid_size + 1) * w // grid_size
    ys = np.arange(grid_size + 1) * h // grid_size
    grid_counts = np.zeros((grid_size, grid_size), dtype=np.int64)
    grid_valid = np.zeros_like(grid_counts, dtype=bool)
    for i in range(grid_size):
        for j in range(grid_size):
            area = (ys[i+1] - ys[i]) * (xs[j+1] - xs[j])
            count = int(valid[ys[i]:ys[i+1], xs[j]:xs[j+1]].sum())
            grid_counts[i, j] = count
            grid_valid[i, j] = area > 0 and count / area >= 0.5
    result = {'valid_pixels': total, 'valid_grids': int(grid_valid.sum()), 'groups': {}}
    regions = (x < 1/3, (x >= 1/3) & (x < 2/3), x >= 2/3)
    for gid, (name, _) in enumerate(GROUPS, 1):
        mask = (group_map == gid) & valid
        count = int(mask.sum())
        grid = np.full((grid_size, grid_size), np.nan)
        for i, j in zip(*np.nonzero(grid_valid)):
            grid[i, j] = mask[ys[i]:ys[i+1], xs[j]:xs[j+1]].sum() / grid_counts[i, j]
        region_ratios = []
        for region in regions:
            denominator = int(valid[:, region].sum())
            region_ratios.append(float(mask[:, region].sum() / denominator) if denominator else np.nan)
        ratio = count / total if total else np.nan
        cx = float((mask.sum(0) * x).sum() / count) if count else np.nan
        cy = float((mask.sum(1) * y).sum() / count) if count else np.nan
        result['groups'][name] = {
            'group_id': gid, 'pixels': count, 'proportion': ratio, 'cx': cx, 'cy': cy,
            'grid': grid.tolist(), 'grid_mean': float(grid[grid_valid].mean()) if grid_valid.any() else np.nan,
            'grid_std': float(grid[grid_valid].std(ddof=0)) if grid_valid.any() else np.nan,
            'left': region_ratios[0], 'center': region_ratios[1], 'right': region_ratios[2],
            'q': [ratio, cx, cy] + grid.ravel(order='C').tolist(),
        }
    result['interface_proportion'] = (result['groups']['building']['proportion'] +
                                      result['groups']['wall_fence']['proportion'])
    return result


def compare(prediction, reference, image_id):
    prediction, reference = np.asarray(prediction), np.asarray(reference)
    if prediction.shape != reference.shape:
        raise ValueError('Prediction and reference must have the original image dimensions.')
    valid = reference != 255
    pred = quantify(prediction, valid)
    ref = quantify(reference, valid)
    pg, rg = GROUP_LUT[prediction.astype(np.uint8)], GROUP_LUT[reference.astype(np.uint8)]
    rows = []
    for gid, (name, _) in enumerate(GROUPS, 1):
        p, r = pred['groups'][name], ref['groups'][name]
        pm, rm = (pg == gid) & valid, (rg == gid) & valid
        union = int((pm | rm).sum())
        paired = p['pixels'] > 0 and r['pixels'] > 0
        difference = np.abs(np.asarray(p['grid']) - np.asarray(r['grid']))
        row = {'image_id': image_id, 'group': name, 'valid_pixels': ref['valid_pixels'],
               'valid_grids': ref['valid_grids'], 'pred_proportion': p['proportion'],
               'ref_proportion': r['proportion'], 'proportion_error_pp': 100 * abs(p['proportion'] - r['proportion']),
               'centroid_error': float(np.hypot(p['cx'] - r['cx'], p['cy'] - r['cy'])) if paired else np.nan,
               'grid_error': float(np.nanmean(difference)) if ref['valid_grids'] else np.nan,
               'iou': float((pm & rm).sum() / union) if union else np.nan,
               'reference_present': r['pixels'] > 0, 'paired_present': paired,
               'miss': p['pixels'] == 0 and r['pixels'] > 0,
               'false_positive': p['pixels'] > 0 and r['pixels'] == 0}
        for prefix, measure in [('pred', p), ('ref', r)]:
            for key in ('cx', 'cy', 'grid_mean', 'grid_std', 'left', 'center', 'right'):
                row[f'{prefix}_{key}'] = measure[key]
        rows.append(row)
    return pred, ref, rows


def _mean(values):
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    return float(values.mean()) if len(values) else np.nan


def summarize(rows):
    summary = {}
    for name, _ in GROUPS:
        subset = [r for r in rows if r['group'] == name and r['valid_pixels'] > 0]
        result = {'n_images': len(subset), 'proportion_mae_pp': _mean([r['proportion_error_pp'] for r in subset]),
                  'centroid_mean_distance': _mean([r['centroid_error'] for r in subset]),
                  'grid_mae': _mean([r['grid_error'] for r in subset]),
                  'n_grid_images': sum(r['valid_grids'] > 0 for r in subset)}
        for key in ('reference_present', 'paired_present', 'miss', 'false_positive'):
            result[key] = sum(r[key] for r in subset)
        for error in ('proportion_error_pp', 'grid_error'):
            paired = [(r['iou'], r[error]) for r in subset if np.isfinite(r['iou']) and np.isfinite(r[error])]
            arr = np.asarray(paired)
            rho, pvalue = np.nan, np.nan
            if len(paired) > 1 and np.ptp(arr[:, 0]) > 0 and np.ptp(arr[:, 1]) > 0:
                stat = spearmanr(arr[:, 0], arr[:, 1])
                rho, pvalue = float(stat.statistic), float(stat.pvalue)
            result[f'spearman_iou_{error}'] = {'rho': rho, 'pvalue': pvalue, 'n': len(paired)}
        summary[name] = result
    return summary
