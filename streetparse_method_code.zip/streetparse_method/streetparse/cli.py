import argparse
import json
import os
import time
from pathlib import Path

import numpy as np
import torch
from PIL import Image

from .data import Cityscapes, normalize
from .engine import device_for, evaluate, load_model, train
from .io import write_csv, write_json
from .labels import GROUP_LUT, RAW_IDS, colorize
from .quantify import compare, quantify


def parser():
    p = argparse.ArgumentParser(description='Street parsing and spatial quantification paper reproduction')
    sub = p.add_subparsers(dest='command', required=True)
    check = sub.add_parser('check-data', help='Check pairs, sizes, counts, and write manifests')
    check.add_argument('--data', default='Cityscapes')
    check.add_argument('--output', default='outputs/data_check')
    check.add_argument('--full', action='store_true', help='Decode every image/label instead of one per split')
    check.add_argument('--limit', type=int)
    su = sub.add_parser('prepare-subset', help='Create fixed city-stratified train/val manifests')
    su.add_argument('--data', default='Cityscapes')
    su.add_argument('--output', default='subsets/cityscapes100')
    su.add_argument('--train-size', type=int, default=100)
    su.add_argument('--val-size', type=int, default=20)
    su.add_argument('--subset-seed', type=int, default=2026)
    tr = sub.add_parser('train')
    tr.add_argument('--data', default='Cityscapes')
    tr.add_argument('--output', default='runs/proposed_seed2026')
    tr.add_argument('--architecture', choices=['proposed', 'deeplab', 'unet', 'pspnet'], default='proposed')
    tr.add_argument('--gate', action=argparse.BooleanOptionalAction, default=None)
    tr.add_argument('--boundary', action=argparse.BooleanOptionalAction, default=None)
    tr.add_argument('--partition', choices=['all', 'fit'], default='all')
    tr.add_argument('--seed', type=int, default=2026)
    tr.add_argument('--epochs', type=int, default=100)
    tr.add_argument('--crop', type=int, nargs=2, default=[512, 1024], metavar=('H', 'W'))
    tr.add_argument('--batch-size', type=int, default=1)
    tr.add_argument('--accumulation', type=int, default=4)
    tr.add_argument('--lr', type=float, default=1e-4)
    tr.add_argument('--boundary-weight', type=float, default=0.2)
    tr.add_argument('--workers', type=int, default=0)
    tr.add_argument('--device', choices=['auto', 'cuda', 'cpu'], default='auto')
    tr.add_argument('--no-pretrained', action='store_true')
    tr.add_argument('--no-amp', action='store_true')
    tr.add_argument('--resume')
    tr.add_argument('--limit', type=int)
    tr.add_argument('--manifest', help='Fixed train subset JSON')
    tr.add_argument('--tune-manifest', help='Fixed internal tune subset JSON (fit partition only)')
    tr.add_argument('--max-batches', type=int)
    tr.add_argument('--tune-limit', type=int)
    tr.add_argument('--eval-size', type=int, nargs=2, help='Optional aspect-preserving validation size; default original')
    tr.add_argument('--log-every', type=int, default=25)
    ev = sub.add_parser('evaluate')
    ev.add_argument('--data', default='Cityscapes')
    ev.add_argument('--checkpoint', required=True)
    ev.add_argument('--output', default='outputs/evaluation')
    ev.add_argument('--split', choices=['train', 'val'], default='val')
    ev.add_argument('--partition', choices=['all', 'fit', 'tune'], default='all')
    ev.add_argument('--device', choices=['auto', 'cuda', 'cpu'], default='auto')
    ev.add_argument('--limit', type=int)
    ev.add_argument('--manifest', help='Fixed evaluation subset JSON')
    ev.add_argument('--eval-size', type=int, nargs=2)
    ev.add_argument('--save-examples', type=int, default=3)
    pr = sub.add_parser('predict')
    pr.add_argument('--checkpoint', required=True)
    pr.add_argument('--input', required=True, help='RGB image or directory (recursive)')
    pr.add_argument('--output', default='outputs/prediction')
    pr.add_argument('--device', choices=['auto', 'cuda', 'cpu'], default='auto')
    pr.add_argument('--eval-size', type=int, nargs=2)
    qu = sub.add_parser('quantify')
    qu.add_argument('--labels', required=True, help='Single-channel 19-class trainIds PNG')
    qu.add_argument('--reference', help='Optional original labelIds PNG for paired verification')
    qu.add_argument('--reference-encoding', choices=['raw', 'train'], default='raw')
    qu.add_argument('--output', default='outputs/quantification.json')
    be = sub.add_parser('benchmark')
    be.add_argument('--checkpoint', required=True)
    be.add_argument('--data', default='Cityscapes')
    be.add_argument('--device', choices=['cuda', 'cpu'], default='cuda')
    be.add_argument('--warmup', type=int, default=50)
    be.add_argument('--iterations', type=int, default=200)
    be.add_argument('--size', type=int, nargs=2, default=[1024, 2048])
    be.add_argument('--output', default='outputs/benchmark.json')
    ag = sub.add_parser('aggregate', help='Mean and sample standard deviation across independent seeds')
    ag.add_argument('--reports', nargs='+', required=True)
    ag.add_argument('--output', default='outputs/aggregate.json')
    return p


def check_data(args):
    report = {}
    for split, partition in [('train', 'all'), ('train', 'fit'), ('train', 'tune'), ('val', 'all')]:
        ds = Cityscapes(args.data, split, partition, limit=args.limit)
        cities = {}
        for r in ds.records:
            cities[r['city']] = cities.get(r['city'], 0) + 1
        indexes = range(len(ds)) if args.full else range(1)
        shapes = set()
        for i in indexes:
            rgb, target = ds.load_pair(i)
            shapes.add((rgb.height, rgb.width))
            if not np.isin(np.asarray(target), list(range(19)) + [255]).all():
                raise ValueError(f'Invalid label {ds.records[i]["id"]}')
            if args.full and (i + 1) % 250 == 0:
                print(f'Check {split}/{partition}: {i+1}/{len(ds)}', flush=True)
        name = f'{split}_{partition}'
        report[name] = {'count': len(ds), 'cities': cities, 'checked_images': len(indexes),
                        'shapes': sorted(shapes), 'sources': {k: str(v) if v else 'extracted' for k,v in ds.sources.items()}}
        write_json(Path(args.output) / f'{name}_manifest.json', ds.records)
    write_json(Path(args.output) / 'summary.json', report)
    print(json.dumps(report, indent=2), flush=True)


@torch.no_grad()
def predict(args):
    from .models import predict_labels
    device = device_for(args.device)
    model, state = load_model(args.checkpoint, device)
    source = Path(args.input)
    files = [source] if source.is_file() else sorted(p for p in source.rglob('*') if p.suffix.lower() in ('.png', '.jpg', '.jpeg', '.bmp'))
    if not files:
        raise FileNotFoundError(f'No images at {source}')
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    for path in files:
        with Image.open(path) as im:
            rgb = im.convert('RGB')
        hw = rgb.height, rgb.width
        image = rgb
        if args.eval_size:
            scale = min(args.eval_size[0] / rgb.height, args.eval_size[1] / rgb.width)
            image = rgb.resize((max(1, round(rgb.width * scale)), max(1, round(rgb.height * scale))), Image.Resampling.BILINEAR)
        labels = predict_labels(model, normalize(image)[None].to(device), hw)[0].cpu().numpy().astype(np.uint8)
        # Preserve subdirectories to prevent duplicate basenames overwriting results.
        relative = Path(path.stem) if source.is_file() else path.relative_to(source).with_suffix('')
        stem = output / relative
        stem.parent.mkdir(parents=True, exist_ok=True)
        Image.fromarray(labels).save(str(stem) + '_trainIds.png')
        Image.fromarray(np.asarray(RAW_IDS, dtype=np.uint8)[labels]).save(str(stem) + '_labelIds.png')
        Image.fromarray(GROUP_LUT[labels]).save(str(stem) + '_groups.png')
        colors = colorize(labels)
        Image.fromarray(colors).save(str(stem) + '_color.png')
        Image.fromarray((0.55*np.asarray(rgb) + 0.45*colors).astype(np.uint8)).save(str(stem) + '_overlay.png')
        write_json(str(stem) + '_quantification.json', quantify(labels))
        print(f'Predicted {path}', flush=True)
    write_json(output / 'run.json', {'checkpoint': str(Path(args.checkpoint).resolve()),
                                    'model_config': state['model_config'], 'n_images': len(files),
                                    'eval_size': args.eval_size, 'valid_mask': 'entire image (no reference provided)'})


@torch.no_grad()
def benchmark(args):
    device = device_for(args.device)
    # FP32 comparison should not silently use TF32 convolution/matmul kernels.
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    model, state = load_model(args.checkpoint, device)
    t0 = time.perf_counter()
    ds = Cityscapes(args.data, 'val', limit=1)
    rgb, _ = ds.load_pair(0)
    read_seconds = time.perf_counter() - t0
    t0 = time.perf_counter()
    rgb = rgb.resize((args.size[1], args.size[0]), Image.Resampling.BILINEAR)
    image = normalize(rgb)[None].to(device)
    sync = (lambda: torch.cuda.synchronize(device)) if device.type == 'cuda' else (lambda: None)
    sync()
    preprocess_seconds = time.perf_counter() - t0
    for _ in range(args.warmup):
        model(image, auxiliary=False)
    sync()
    if device.type == 'cuda':
        torch.cuda.reset_peak_memory_stats(device)
    elapsed = []
    for _ in range(args.iterations):
        sync()
        t0 = time.perf_counter()
        model(image, auxiliary=False)
        sync()
        elapsed.append(1000 * (time.perf_counter() - t0))
    from .models import predict_labels
    labels = predict_labels(model, image, args.size)[0].cpu().numpy()
    t0 = time.perf_counter()
    quantify(labels)
    quantification_seconds = time.perf_counter() - t0
    aux = sum(p.numel() for n, p in model.named_parameters() if n.startswith('boundary_head'))
    params = sum(p.numel() for p in model.parameters())
    report = {'forward_mean_ms': float(np.mean(elapsed)), 'forward_std_ms': float(np.std(elapsed)),
              'read_ms': 1000 * read_seconds, 'preprocess_ms': 1000 * preprocess_seconds,
              'quantify_ms': 1000 * quantification_seconds, 'training_parameters': params,
              'inference_parameters': params - aux, 'boundary_parameters': aux,
              'device': str(device), 'precision': 'FP32', 'tf32': False, 'size': args.size,
              'warmup': args.warmup, 'iterations': args.iterations,
              'peak_cuda_allocated_mb': torch.cuda.max_memory_allocated(device)/2**20 if device.type == 'cuda' else None}
    write_json(args.output, report)
    print(json.dumps(report, indent=2))


def aggregate(args):
    reports = [json.loads(Path(p).read_text(encoding='utf-8')) for p in args.reports]
    if len(reports) < 2:
        raise ValueError('Sample standard deviation requires at least two independent runs.')
    metadata = [r.get('checkpoint_metadata', {}) for r in reports]
    seeds = [m.get('seed') for m in metadata]
    if None in seeds or len(set(seeds)) != len(seeds):
        raise ValueError('Reports must contain distinct independent random seeds.')
    domains = [(r['n_images'], r['split'], r['partition'], r['eval_size'],
                r.get('sample_ids'), m.get('model_config')) for r,m in zip(reports,metadata)]
    if any(d != domains[0] for d in domains[1:]):
        raise ValueError('Reports must use identical models and evaluation samples/settings.')
    def flatten(obj, prefix=''):
        result = {}
        for key, value in obj.items():
            name = f'{prefix}.{key}' if prefix else key
            if isinstance(value, dict):
                result.update(flatten(value, name))
            elif isinstance(value, (float, int)) and not isinstance(value, bool):
                result[name] = value
        return result
    flat = [flatten({'segmentation': r['segmentation'], 'quantification': r['quantification']}) for r in reports]
    results = {}
    for key in sorted(set.intersection(*(set(f) for f in flat))):
        values = [f[key] for f in flat]
        results[key] = {'mean': float(np.mean(values)), 'sample_std': float(np.std(values, ddof=1)), 'n': len(values)}
    write_json(args.output, {'reports': args.reports, 'seeds': seeds, 'metrics': results})


def main():
    os.environ.setdefault('TORCH_HOME', str(Path('outputs/torch_cache').resolve()))
    args = parser().parse_args()
    # Validate common positive counts to avoid silent malformed experiments.
    for name in ('epochs', 'batch_size', 'accumulation', 'iterations', 'log_every', 'limit', 'max_batches', 'tune_limit'):
        value = getattr(args, name, None)
        if value is not None and value < 1:
            raise ValueError(f'{name} must be positive')
    for name in ('crop', 'eval_size', 'size'):
        value = getattr(args, name, None)
        if value is not None and any(x < 1 for x in value):
            raise ValueError(f'{name} dimensions must be positive')
    if getattr(args, 'boundary_weight', 0) < 0 or getattr(args, 'workers', 0) < 0:
        raise ValueError('boundary weight and workers must be nonnegative')
    if getattr(args, 'warmup', 0) < 0:
        raise ValueError('warmup must be nonnegative')
    if args.command == 'prepare-subset':
        from .subsets import prepare_subset
        summary = prepare_subset(args.data, args.output, args.train_size, args.val_size, args.subset_seed)
        print(json.dumps({k: {'count': v['count'], 'cities': v['cities']} for k, v in summary['sets'].items()}, indent=2))
    elif args.command == 'check-data':
        check_data(args)
    elif args.command == 'train':
        train(args)
    elif args.command == 'evaluate':
        device = device_for(args.device)
        model, state = load_model(args.checkpoint, device)
        ds = Cityscapes(args.data, args.split, args.partition, eval_size=args.eval_size, limit=args.limit, manifest=args.manifest)
        report = evaluate(model, ds, device, args.output, args.save_examples)
        report['checkpoint_metadata'] = {'path': str(Path(args.checkpoint).resolve()),
                                         'epoch': state['epoch'], 'seed': state['train_config']['seed'],
                                         'model_config': state['model_config'],
                                         'boundary_weight': state['train_config']['boundary_weight']}
        report['checkpoint_metadata']['train_manifest'] = state['train_config'].get('manifest')
        report['evaluation_manifest'] = args.manifest
        report['sample_ids'] = [r['id'] for r in ds.records]
        write_json(Path(args.output) / 'summary.json', report)
        print(f'mIoU={report["segmentation"]["miou"]:.5f}, boundary F1={report["segmentation"]["boundary_f1"]:.5f}')
    elif args.command == 'predict':
        predict(args)
    elif args.command == 'quantify':
        from .labels import to_train_ids
        with Image.open(args.labels) as image:
            labels = np.asarray(image)
        if args.reference:
            with Image.open(args.reference) as image:
                reference = np.asarray(image)
            if args.reference_encoding == 'raw':
                reference = to_train_ids(reference)
            pred, ref, rows = compare(labels, reference, Path(args.labels).stem)
            result = {'prediction': pred, 'reference': ref, 'errors': rows}
        else:
            result = quantify(labels)
        write_json(args.output, result)
    elif args.command == 'benchmark':
        benchmark(args)
    elif args.command == 'aggregate':
        aggregate(args)


if __name__ == '__main__':
    main()
