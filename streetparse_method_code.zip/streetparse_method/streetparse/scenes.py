"""Reference-only mutually exclusive scene groups and conditional error summaries."""
import math
from statistics import fmean

SCENE_NAMES={'building':'建筑主导','vegetation':'植被主导',
             'dynamic':'动态对象占比较高','mixed':'混合场景'}


def classify_scene(building, vegetation, dynamic, dominant_threshold=.30, dynamic_threshold=.10):
    for value in (building,vegetation,dynamic):
        if not math.isfinite(value) or not 0<=value<=1:
            raise ValueError('Scene proportions must be finite and within [0,1].')
    if not 0<dominant_threshold<=1 or not 0<dynamic_threshold<=1:
        raise ValueError('Scene thresholds must lie in (0,1].')
    if dynamic>=dynamic_threshold:
        return 'dynamic'
    if building>=dominant_threshold and building>=vegetation:
        return 'building'
    if vegetation>=dominant_threshold:
        return 'vegetation'
    return 'mixed'


def numeric(value):
    if value in ('',None):return math.nan
    return float(value)


def finite_mean(values):
    values=[numeric(v) for v in values]
    values=[v for v in values if math.isfinite(v)]
    return fmean(values) if values else None


def group_error_summary(rows):
    return {'n_images':len({r['image_id'] for r in rows}),
            'proportion_mae_pp':finite_mean(r['proportion_error_pp'] for r in rows),
            'centroid_distance':finite_mean(r['centroid_error'] for r in rows),
            'centroid_pairs':sum(math.isfinite(numeric(r['centroid_error'])) for r in rows),
            'grid_mae':finite_mean(r['grid_error'] for r in rows),
            'grid_pairs':sum(math.isfinite(numeric(r['grid_error'])) for r in rows)}
