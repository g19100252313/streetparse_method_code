"""Run six exploratory configurations on the same fixed 100-image subset."""
import argparse
import json
import subprocess
import sys
import time
from pathlib import Path

from experiments import VARIANTS
from streetparse.io import write_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', default='Cityscapes')
    parser.add_argument('--subset-dir', default='subsets/cityscapes100')
    parser.add_argument('--run-root', default='runs/subset100')
    parser.add_argument('--output-root', default='outputs/subset100')
    parser.add_argument('--epochs', type=int, default=20)
    parser.add_argument('--seed', type=int, default=2026)
    parser.add_argument('--boundary-weight', type=float, default=0.2)
    parser.add_argument('--variants', nargs='+', choices=list(VARIANTS), default=list(VARIANTS))
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if args.epochs < 1 or args.boundary_weight < 0:
        parser.error('epochs must be positive; boundary weight nonnegative')
    manifests = Path(args.subset_dir)
    train_manifest, val_manifest = manifests / 'train.json', manifests / 'val.json'
    for path, split in [(train_manifest, 'train'), (val_manifest, 'val')]:
        content = json.loads(path.read_text(encoding='utf-8'))
        if content['split'] != split or content['partition'] != 'all':
            raise ValueError(f'Unexpected subset manifest: {path}')
    prefix = [sys.executable, '-u', '-m', 'streetparse.cli']
    jobs = []
    for variant in args.variants:
        run = Path(args.run_root) / f'{variant}_seed{args.seed}'
        output = Path(args.output_root) / f'{variant}_seed{args.seed}'
        command = prefix + ['train', '--data', args.data, '--manifest', str(train_manifest),
                            '--seed', str(args.seed), '--epochs', str(args.epochs),
                            '--boundary-weight', str(args.boundary_weight), '--log-every', '100',
                            '--output', str(run)] + VARIANTS[variant]
        if (run / 'last.pt').exists():
            command += ['--resume', str(run / 'last.pt')]
        jobs.append({'variant': variant, 'stage': 'train', 'command': command, 'status': 'pending'})
        jobs.append({'variant': variant, 'stage': 'evaluate', 'command': prefix +
                     ['evaluate', '--data', args.data, '--manifest', str(val_manifest),
                      '--checkpoint', str(run / 'last.pt'), '--output', str(output)], 'status': 'pending'})
    state = {'scope': '100-image exploratory subset, not the full paper experiment',
             'epochs': args.epochs, 'seed': args.seed, 'boundary_weight': args.boundary_weight,
             'lambda_selection': 'fixed quick-run value, no lambda search',
             'train_manifest': str(train_manifest.resolve()), 'val_manifest': str(val_manifest.resolve()),
             'jobs': jobs, 'status': 'planned'}
    output_root = Path(args.output_root)
    write_json(output_root / 'plan.json', state)
    if not args.run:
        for job in jobs:
            print(subprocess.list2cmdline(job['command']))
        return
    state['status'] = 'running'
    start = time.perf_counter()
    try:
        for job in jobs:
            job['status'] = 'running'
            write_json(output_root / 'progress.json', state)
            print(f'\nStarting {job["variant"]}: {job["stage"]}', flush=True)
            stage_start = time.perf_counter()
            subprocess.run(job['command'], check=True)
            job['seconds'] = time.perf_counter() - stage_start
            job['status'] = 'complete'
            write_json(output_root / 'progress.json', state)
        comparison = []
        for variant in args.variants:
            result = json.loads((output_root / f'{variant}_seed{args.seed}' / 'summary.json').read_text(encoding='utf-8'))
            comparison.append({'variant': variant, 'seed': args.seed, 'epochs': args.epochs,
                               'miou': result['segmentation']['miou'],
                               'boundary_f1': result['segmentation']['boundary_f1'],
                               'n_validation_images': result['n_images'],
                               'quantification': result['quantification']})
        write_json(output_root / 'comparison.json', {'scope': state['scope'], 'results': comparison})
        state['status'] = 'complete'
    except Exception as error:
        job['status'] = 'failed'
        state['status'] = 'failed'
        state['error'] = str(error)
        raise
    finally:
        state['total_seconds'] = time.perf_counter() - start
        write_json(output_root / 'progress.json', state)
    print(f'Completed subset experiments in {state["total_seconds"]/60:.1f} minutes.', flush=True)


if __name__ == '__main__':
    main()
