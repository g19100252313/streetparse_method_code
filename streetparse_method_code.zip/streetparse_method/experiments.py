"""Generate or execute the paper's tune/final experiment protocol sequentially."""
import argparse
import json
import subprocess
import sys
from pathlib import Path

import torch

from streetparse.io import write_json

VARIANTS = {
    'proposed': ['--architecture', 'proposed'],
    'deeplab': ['--architecture', 'deeplab'],
    'gate_only': ['--architecture', 'deeplab', '--gate'],
    'boundary_only': ['--architecture', 'deeplab', '--boundary'],
    'unet': ['--architecture', 'unet'],
    'pspnet': ['--architecture', 'pspnet'],
}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage', choices=['tune', 'select', 'final'])
    p.add_argument('--data', default='Cityscapes')
    p.add_argument('--root', default='runs/paper')
    p.add_argument('--epochs', type=int, default=100)
    p.add_argument('--seeds', type=int, nargs='+', default=[2026, 2027, 2028])
    p.add_argument('--variants', nargs='+', choices=list(VARIANTS), default=list(VARIANTS))
    p.add_argument('--run', action='store_true', help='Execute; default only writes and prints the plan')
    args = p.parse_args()
    if args.epochs < 1 or len(args.seeds) != len(set(args.seeds)):
        p.error('epochs must be positive and seeds must be distinct')
    root = Path(args.root)
    selection = root / 'lambda_selection.json'
    prefix = [sys.executable, '-m', 'streetparse.cli']
    commands = []
    if args.stage == 'tune':
        for weight in (0.1, 0.2, 0.5):
            run = root / f'tune_lambda{weight}'
            command = prefix + ['train', '--data', args.data, '--partition', 'fit', '--seed', '2026',
                                '--boundary-weight', str(weight), '--epochs', str(args.epochs), '--output', str(run)]
            if (run / 'last.pt').exists():
                command += ['--resume', str(run / 'last.pt')]
            commands.append(command)
    elif args.stage == 'select':
        candidates = []
        signatures = []
        for weight in (0.1, 0.2, 0.5):
            run = root / f'tune_lambda{weight}'
            checkpoint = run / 'best.pt'
            last = torch.load(run / 'last.pt', map_location='cpu', weights_only=False)
            state = torch.load(checkpoint, map_location='cpu', weights_only=False)
            config = state['train_config']
            if last['epoch'] != config['epochs'] or config['partition'] != 'fit' or config['limit'] or config['tune_limit'] or config['max_batches'] or config.get('manifest') or config.get('tune_manifest'):
                raise ValueError(f'{run}: incomplete or reduced tuning experiment cannot select paper lambda.')
            if config['boundary_weight'] != weight or state['model_config'] != {'architecture': 'proposed', 'gate': True, 'boundary': True}:
                raise ValueError(f'{run}: candidate model/weight does not match the tuning protocol.')
            signatures.append({key: config[key] for key in ('epochs', 'seed', 'crop', 'batch_size',
                                                           'accumulation', 'lr', 'no_pretrained', 'no_amp', 'eval_size')})
            candidates.append({'weight': weight, 'best_tune_miou': state['best_tune_miou'],
                               'best_epoch': state['epoch'], 'checkpoint': str(checkpoint)})
        if any(s != signatures[0] for s in signatures[1:]):
            raise ValueError('Lambda candidates must share all other training settings.')
        selected = max(candidates, key=lambda x: x['best_tune_miou'])
        write_json(selection, {'boundary_weight': selected['weight'], 'selection_metric': 'internal tune best mIoU',
                               'candidates': candidates, 'seed': 2026})
        print(f'Selected lambda={selected["weight"]}; {selection}')
        return
    else:
        if not selection.is_file():
            raise FileNotFoundError(f'Run tune then select before final: missing {selection}')
        weight = json.loads(selection.read_text(encoding='utf-8'))['boundary_weight']
        for variant in args.variants:
            reports = []
            for seed in args.seeds:
                run = root / f'{variant}_seed{seed}'
                output = Path('outputs/paper') / f'{variant}_seed{seed}'
                reports.append(str(output / 'summary.json'))
                command = prefix + ['train', '--data', args.data, '--partition', 'all',
                                    '--seed', str(seed), '--boundary-weight', str(weight),
                                    '--epochs', str(args.epochs), '--output', str(run)] + VARIANTS[variant]
                if (run / 'last.pt').exists():
                    command += ['--resume', str(run / 'last.pt')]
                commands.append(command)
                commands.append(prefix + ['evaluate', '--data', args.data, '--checkpoint', str(run / 'last.pt'),
                                           '--output', str(output)])
            if len(reports) > 1:
                commands.append(prefix + ['aggregate', '--reports'] + reports +
                                ['--output', f'outputs/paper/{variant}_aggregate.json'])
    write_json(root / f'{args.stage}_plan.json', {'stage': args.stage, 'commands': commands, 'execute': args.run})
    for command in commands:
        print(subprocess.list2cmdline(command), flush=True)
        if args.run:
            subprocess.run(command, check=True)


if __name__ == '__main__':
    main()
